
            
<html>
    <head>
    <link rel="stylesheet" href="./styles/index.css">
            <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script><style>
      body{
        background-color:gainsboro;
      }
  .bottom-right {
    position: absolute;
    bottom: 50px;
    right: 340px;
    font-family: Georgia, 'Times New Roman', Times, serif;
    font-size: 50px;
    
    
  }
        table{
            border: 1px solid white;
             border-collapse: collapse;
             width: 50%;
             
            
        
        }
        th{
            color:blue;
            font-size: 35px; 
        }
        td{
            font-size: 25px; 
        }
        th, td {
              
              padding: 8px;
              
              text-align: left;
              border-bottom: 1px solid #DDD;
               }
        tr:hover {background-color:brown;}

        h1{
            color:green;
        }
        h3{
            color:red;
        }
        </style>
        </head>
        <body><center>

        <nav>
        <div class="header">
        <div class="header-logo">
            <div class=" logo1 col-sm-2 text-center">
                <img src="./images/TNPSC-logo1.jpg" alt="">
            </div>
            <div class=" logo2 col-md-8 text-center">
                <img src="./images/TNPSC-logo2.png" alt="">
            </div>
            <div class=" logo3 col-md-2 text-center">
                <img src="./images/90year.jpg" alt="">
            </div>
        </div>
        </div>
    </nav>
    <div class="scroller col-md-8 col-sm-6 col-xs-12">
            <marquee behavior="scroll" direction="left">Welcome to TamilNadu Public Service Commission.</marquee>
        </div>
        
            
            <?php
                 include("connection.php");
                 $sslcregno=$_POST["sslcregno"];
                 $sql="SELECT * FROM mark WHERE sslcregno=$sslcregno";
                 $mark="SELECT mark_percentage FROM mark WHERE sslcregno=$sslcregno";
                 
                 echo "<table border='1'>
                 <br>
                 <b> <h1>Results Group4 </h1></b><br>
                 
                 <tr>
                 <th><h2>Register No</h2></th>
                 <th><h2>Name</h2></th>
                 <th><h2>Marks Percentage</h2></th>
                
                 
                 
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while ($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
        echo "<td>" . $rows['name'] . "</td>";
        echo "<td>" . $rows['mark_percentage'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['widow'] . "</td>";
        
        
        
        echo "</tr>";
    }
    echo "</table> <br> <br> <br>";
    // echo "<h2> Congratulations You are selected !!!</h2> ";
}
else{
    echo "<table>";
    echo "error: ". $sql . "<br>" .$conn->error; 
}

// $sql1="select sslcregno,name from mark where mark_percentage > 80 and sslcregno in (SELECT sslcregno FROM form3 where community='OC'and widow='yes')" ;
if (($sslcregno =="1046")||($sslcregno =="1024")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1007")||($sslcregno =="1052")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1053")||($sslcregno =="1050")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1019")||($sslcregno =="1020")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
// elseif(($sslcregno =="1019")||($sslcregno =="1020")){
//     echo "<h1>Congratulations You are selected !!!!</h1>";
// }
// elseif(($sslcregno =="1019")||($sslcregno =="1020")){
//     echo "<h1>Congratulations You are selected !!!!</h1>";
// }
elseif(($sslcregno =="1021")||($sslcregno =="1042")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1043")||($sslcregno =="1044")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1046")||($sslcregno =="1006")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1052")||($sslcregno =="1034")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1035")||($sslcregno =="1036")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1037")||($sslcregno =="1038")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1039")||($sslcregno =="1040")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1041")||($sslcregno =="1044")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
elseif(($sslcregno =="1045")||($sslcregno =="1025")){
    echo "<h1>Congratulations You are selected !!!!</h1>";
}
else{
    echo"<h3>Better Luck NextTime!!!!!!";
};




// if (($sslcregno =="1046")||($sslcregno =="1024")||($sslcregno =="1007")||($sslcregno =="1052")||($sslcregno =="1053")||($sslcregno =="1050")||($sslcregno =="1019")||($sslcregno =="1020")||($sslcregno =="1021")||($sslcregno =="1042")||($sslcregno =="1043")||($sslcregno =="1044")||($sslcregno =="1044")||($sslcregno =="1046")($sslcregno =="1004")||($sslcregno =="1006")||($sslcregno =="1052")||($sslcregno =="1034")||($sslcregno =="1035")||($sslcregno =="1036")||($sslcregno =="1037")||($sslcregno =="1038")||($sslcregno =="1039")||($sslcregno =="1040")||($sslcregno =="1041")||($sslcregno =="1044")||($sslcregno =="1045")||($sslcregno =="1025")) {
//   echo "<h1>Congratulations You are selected !!!!</h1>";
// }
// else{
//     echo"hii";
// };

//   elseif("") {
//     echo "Have a good night!";
//   }


//   $sql2="select sslcregno,name from mark where mark_percentage > 77 and sslcregno in (SELECT sslcregno FROM form3 where community='BC'and widow='yes')" ;

//   if ($sql2) {
//     echo "Have a good day!";
//   }
//   else {
//       echo "Have a good night!";
//     }
//     $sql3="select sslcregno,name from mark where mark_percentage > 80 and sslcregno in (SELECT sslcregno FROM form3 where community='MBC'and widow='yes')" ;

//     if ($sql3) {
//       echo "Have a good day!";
//     }
//     else {
//         echo "Have a good night!";
//       }
//       $sql4="select sslcregno,name from mark where mark_percentage > 80 and sslcregno in (SELECT sslcregno FROM form3 where community='SC'and widow='yes')" ;

//       if ($sql4) {
//         echo "Have a good day!";
//       }
//       else {
//           echo "Have a good night!";
//         }

//         $sql5="select sslcregno,name from mark where mark_percentage > 60 and sslcregno in (SELECT sslcregno FROM form3 where community='ST'and widow='yes')" ;

//       if ($sql5) {
//         echo "Have a good day!";
//       }
//       else {
//           echo "Have a good night!";
//         }
        
$conn->close();
?>

</center>

<br><br>

<footer>
    <img src="./images/india.gov.in.jpg" alt="">
    <div class="con">
    <div>© Tamil Nadu Public Service Commission, TNPSC Road, Broadway, Chennai-600003. </div>
    <!-- <div>Email: grievance[dot]tnpsc[at]tn[dot]gov[dot]in</div> -->
</div>
    <img class="footer-img2" src="./images/tn.gov.in2.jpg" alt="">
</footer>
        </body>
</html>