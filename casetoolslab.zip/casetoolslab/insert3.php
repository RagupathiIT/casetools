<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=mysqli_connect($server,$username,$password,$dbname);
if(isset($_POST['name'])&& !empty($_POST['currentstatus'])&& !empty($_POST['nationality'])&& !empty($_POST['religion'])&& !empty($_POST['community'])&& !empty($_POST['caste'])&& !empty($_POST['birthplace'])&& !empty($_POST['native'])&& !empty($_POST['candidatemobile'])&& !empty($_POST['maritalstatus'])&& !empty($_POST['gender'])&& !empty($_POST['widow'])&& !empty($_POST['fathersname'])&& !empty($_POST['mothersname'])&& !empty($_POST['parentmobile'])&& !empty($_POST['sslcmark'])&& !empty($_POST['sslcpercentage'])&& !empty($_POST['hscmark'])&& !empty($_POST['hscpercentage'])){
   $name=$_POST['name'];
   $currentstatus=$_POST['currentstatus'];
   $nationality=$_POST['nationality'];
   $religion=$_POST['religion'];
   $community=$_POST['community'];

   $caste=$_POST['caste'];
   $birthplace=$_POST['birthplace'];
   $native=$_POST['native'];
   $candidatemobile=$_POST['candidatemobile'];
   $maritalstatus=$_POST['maritalstatus'];

   $gender=$_POST['gender'];
   $widow=$_POST['widow'];
   $fathersname=$_POST['fathersname'];
   $mothersname=$_POST['mothersname'];
   $parentmobile=$_POST['parentmobile'];

   $sslcmark=$_POST['sslcmark'];
   $sslcpercentage=$_POST['sslcpercentage'];
   $hscmark=$_POST['hscmark'];
   $hscpercentage=$_POST['hscpercentage'];

   $query="insert into form3(name,currentstatus,nationality,religion,community,caste,birthplace,native,candidatemobile,maritalstatus,gender,widow,fathersname,mothersname,parentmobile,sslcmark,sslcpercentage,hscmark,hscpercentage) values('$name','$currentstatus','$nationality','$religion','$community','$caste','$birthplace','$native','$candidatemobile','$maritalstatus','$gender','$widow','$fathersname','$mothersname','$parentmobile','$sslcmark','$sslcpercentage','$hscmark','$hscpercentage')";
   $run=mysqli_query($conn,$query)or die(mysqli_error());
   if($run){
    echo"form submitted";
   }
   else{
    echo"form not submitted";
   }
}
else{
    echo"all feilds are required";
}
?>