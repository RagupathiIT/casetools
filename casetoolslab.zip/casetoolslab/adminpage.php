<html>


    <head>
    <link rel="stylesheet" href="./styles/index.css">
    
        <style>
            body{
                background-color:gainsboro;

            }
        table{
            border-style:solid;
            border-collapse:collapse;
            border-width:2px;
            border-color:black;
            padding:40px;
            width:60%;
            height:60%;
            
        }
        </style>
        </head>
        <body style="background-color:gainsboro;"><center>
        <nav>
        <div class="header">
        <div class="header-logo">
            <div class=" logo1 col-sm-2 text-center">
                <img src="./images/TNPSC-logo1.jpg" alt="">
            </div>
            <div class=" logo2 col-md-8 text-center">
                <img src="./images/TNPSC-logo2.png" alt="">
            </div>
            <div class=" logo3 col-md-2 text-center">
                <img src="./images/90year.jpg" alt="">
            </div>
        </div>
        </div>
    </nav>
    
            


   
    <!-- navbar logo :: ends -->
        <!-- Scroll ::starts -->
        <div class="scroller col-md-8 col-sm-6 col-xs-12">
            <marquee behavior="scroll" direction="left">Welcome to TamilNadu Public Service Commission.</marquee>
        </div>
        <!-- Scroll ::ends -->
<br><br>



        
            <?php
                 include("connection.php");
                 
                 $sql="select sslcregno,name from mark where mark_percentage > 85 and sslcregno in (SELECT sslcregno FROM form3 where community='OC'and widow='yes')" ;
                 echo "  <h1>OC widow</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}

$sql="select sslcregno,name from mark where mark_percentage > 80 and sslcregno in (SELECT sslcregno FROM form3 where community='BC'and widow='yes')" ;
                 echo "  <h1>BC widow</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}

$sql="select sslcregno,name from mark where mark_percentage > 85 and sslcregno in (SELECT sslcregno FROM form3 where community='MBC'and widow='yes')" ;
                 echo "  <h1>MBC widow</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}

$sql="select sslcregno,name from mark where mark_percentage > 95 and sslcregno in (SELECT sslcregno FROM form3 where community='SC'and widow='yes')" ;
                 echo "  <h1>SC widow</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}

$sql="select sslcregno,name from mark where mark_percentage > 60 and sslcregno in (SELECT sslcregno FROM form3 where community='ST'and widow='yes')" ;
                 echo "  <h1>ST widow</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
//women

$sql="select sslcregno,name from mark where mark_percentage > 89 and sslcregno in (SELECT sslcregno FROM form3 where community='BC'and gender='female')" ;
                 echo "  <h1>BC WOMEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
    $sql="select sslcregno,name from mark where mark_percentage > 88 and sslcregno in (SELECT sslcregno FROM form3 where community='OC'and gender='female')" ;
                 echo "  <h1>OC WOMEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
}
$sql="select sslcregno,name from mark where mark_percentage > 89 and sslcregno in (SELECT sslcregno FROM form3 where community='MBC'and gender='female')" ;
                 echo "  <h1>MBC WOMEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
// $sql="select sslcregno,name from mark where mark_percentage > 50 and sslcregno in (SELECT sslcregno FROM form3 where community='ST'and gender='female')" ;
//                  echo "  <h1>ST WOMEN</h1>               <table border='1'>
//                  <br>
                 
//                  <tr>
//                  <th>RegNo</th>
//                  <th>Name</th>
                
//                  </tr>";
//                  $result=$conn->query($sql);
//                  if($result->num_rows>0){
//     while($rows=$result->fetch_assoc()){
//         echo "<tr>";
//         echo "<td>" . $rows['sslcregno'] . "</td>";
//          echo "<td>" . $rows['name'] . "</td>";
//         // echo "<td>" . $rows['maritalstatus'] . "</td>";
//         // echo "<td>" . $rows['gender'] . "</td>";
//         // echo "<td>" . $rows['gender'] . "</td>";
         

//         echo "</tr>";
//     }
//     echo "</table>";
// }
$sql="select sslcregno,name from mark where mark_percentage > 98 and sslcregno in (SELECT sslcregno FROM form3 where community='SC'and gender='female')" ;
                 echo "  <h1>SC WOMEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
$sql="select sslcregno,name from mark where mark_percentage > 82 and sslcregno in (SELECT sslcregno FROM form3 where community='OC'and gender='male')" ;
                 echo "  <h1>OC MEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
$sql="select sslcregno,name from mark where mark_percentage > 60 and sslcregno in (SELECT sslcregno FROM form3 where community='BC'and gender='male')" ;
                 echo "  <h1>BC MEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
$sql="select sslcregno,name from mark where mark_percentage > 75 and sslcregno in (SELECT sslcregno FROM form3 where community='MBC'and gender='male')" ;
                 echo "  <h1>MBC MEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
$sql="select sslcregno,name from mark where mark_percentage > 40 and sslcregno in (SELECT sslcregno FROM form3 where community='SC'and gender='male')" ;
                 echo "  <h1>SC MEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}
$sql="select sslcregno,name from mark where mark_percentage > 90 and sslcregno in (SELECT sslcregno FROM form3 where community='ST'and gender='male')" ;
                 echo "  <h1>ST MEN</h1>               <table border='1'>
                 <br>
                 
                 <tr>
                 <th>RegNo</th>
                 <th>Name</th>
                
                 </tr>";
                 $result=$conn->query($sql);
                 if($result->num_rows>0){
    while($rows=$result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $rows['sslcregno'] . "</td>";
         echo "<td>" . $rows['name'] . "</td>";
        // echo "<td>" . $rows['maritalstatus'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
        // echo "<td>" . $rows['gender'] . "</td>";
         

        echo "</tr>";
    }
    echo "</table>";
}

else{
    echo "<table>";
    echo "error: ". $sql . "<br>" .$conn->error; 
}
$conn->close();
?></center>
        </body>
</html>