-- mark
CREATE TABLE `mark` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sslcregno` varchar(100) NOT NULL,
  `mark_percentage` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mark` (`id`, `name`, `sslcregno`, `mark_percentage`) VALUES

-- mbc
(1, 'Rajasekar','1001','88'),
(2, 'rdx','1002','93'),
(3,  'babu','1003','92'),
(4,  'RAKS','1004', '90'),
(5,  'NAVA','1005','80'),
(6,  'RAJI','1006','91' ),
(7,  'DEEPI','1007','87' ),
(8,  'DHARSHU','1008','88'),
(9,  'kani','1009','84'),
(10,  'vive','1010','70'),
(11, 'vimal','1011','51'),
(12,  'nandha','1012','79'),

-- bc
(13,  'Raja','1013','60'),
(14,  'Sekar','1014','40'),
(15,  'Sham','1015','87'),
(16,  'Naveen','1016','86'),
(17,  'Adam','1017','90'),
(18,  'Anbu','1018','94'),
(19,  'Vetri','1019','93'),
(20,  'Riya','1020','95'),
(21,  'Reena','1021','98'),
(22,  'Sruthi','1022','89'),
(23,  'Anusha','1023','88'),
(24,  'Devi','1024','82'),
(25,  'Dolly','1025','70'),
(26,  'Sweety','1026','78'),

-- oc
(27,  'Anbu','1027','60'),
(28,  'Arivu','1028','40'),
(29,  'Arivu','1029','79'),
(30,  'Ram','1030','78'),
(31,  'Ravi','1031','80'),
(32,  'sakthi','1032','81'),
(33,  'sabari','1033','82'),
(34,  'surandhar','1034','83'),
(35,  'surendhar','1035','84'),
(36,  'navasakthi','1036','85'),
(37,  'nava','1037','86'),
(38,  'nidhish','1038','87'),
(39,  'rajaram','1039','88'),
(40,  'sabarimuthu','1040','89'),
(41,  'Anbu','1041','90'),
(42,  'ramya','1042','97'),
(43,  'jenifer','1043','95'),
(44,  'raji','1044','90'),
(45,  'rajalakshmi','1045','88'),
(46,  'kavya','1046','89'),
(47,  'kavyapriya','1047','83'),

-- st
(48,  'dev','1048','97'),
(49,  'keshav','1049','89'),
(50,  'civiya','1050','95'),
(51,  'gayu','1051','90'),

-- sc
(52,  'Priya','1052','99'),
(53,  'Swetha','1053','97'),
(54,  'Sunitha','1054','95'),
(55,  'Anu','1055','82'),
(56,  'Anish','1056','81'),
(57,  'Sureh','1057','83'),
(58,  'Ramesh','1058','84'),
(59,  'Rihaan','1059','85'),
(60,  'Vihaan','1060','86'),
(61,  'Riyan','1061','60');
ALTER TABLE `mark`
  ADD PRIMARY KEY (`sslcregno`);
  