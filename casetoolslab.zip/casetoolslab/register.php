






<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>

<link rel="stylesheet" href="./styles/index.css">
</head>
<body>
<nav>
        <div class="header">
        <div class="header-logo">
            <div class=" logo1 col-sm-2 text-center">
                <img src="./images/TNPSC-logo1.jpg" alt="">
            </div>
            <div class=" logo2 col-md-8 text-center">
                <img src="./images/TNPSC-logo2.png" alt="">
            </div>
            <div class=" logo3 col-md-2 text-center">
                <img src="./images/90year.jpg" alt="">
            </div>
        </div>
        </div>
    </nav>

<!-- Navbar :: starts -->
<nav class="navbar navbar-expand-sm navbar-dark py-0 ">
    <div class="container-fluid">
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#"><b>Home</b></a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="http://localhost/casetoolslab/login.php">LOGIN</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link active" href="#">Recuritment</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Employee Corner</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="./search.html">Display</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">RTI & Public Grievance</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">FAQ</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Forms & Downloads</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="http://localhost/casetoolslab/register.php">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="http://localhost/casetoolslab/index1.php">ADMIN LOGIN</a>
          </li>

            </ul>
          </li>
          
        </ul>
       
      </div>
    </div>
  </nav>
<!-- Navbar :: ends -->


   
    <!-- navbar logo :: ends -->
        <!-- Scroll ::starts -->
        <div class="scroller col-md-8 col-sm-6 col-xs-12">
            <marquee behavior="scroll" direction="left">Welcome to TamilNadu Public Service Commission.</marquee>
        </div>
        <!-- Scroll ::ends -->
<br><br>
<!-- Login :: starts -->
<!-- <div class="login-sec">
    <form class="login">
        <div class="form-group">
        <input type="text" placeholder="Username" id="username" class="form-control">
        </div><br>
        <div class="form-group">
        <input type="password" placeholder="Password" id="password" class="form-control">
        </div><br>
        <div class="form-group">
        <label for="rememberme">
        <input type="checkbox" name="rememberme" id="rememberme">
        Remember Password
        </label>
        </div><br>
        <div class="form-group">
        <button class="button1" ><a href="registeration1.html" style="color:white ;">Login</a></button>
        </div><br>
        <div class="form-group">
        <p>Not Registered? <a href="signup.html">Sign Up</a></p>
        </div>
        </form>
</div> -->

   <center> <div class="wrapper">
        <h1>Sign Up</h1>
        <p>Please fill this form to create an account.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-secondary ml-2" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form></center>




<!-- Login :: Ends -->
<br><br>

<!-- Footer :: starts -->
<footer>
    <img src="./images/india.gov.in.jpg" alt="">
    <div class="con">
    <div>© Tamil Nadu Public Service Commission, TNPSC Road, Broadway, Chennai-600003. </div>
    <!-- <div>Email: grievance[dot]tnpsc[at]tn[dot]gov[dot]in</div> -->
</div>
    <img class="footer-img2" src="./images/tn.gov.in2.jpg" alt="">
</footer>
<!-- Footer :: ends -->
</body>
</html>










</body>
</html>