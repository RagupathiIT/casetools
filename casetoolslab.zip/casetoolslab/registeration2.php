<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/registeration2.css">
    <script src="https://kit.fontawesome.com/2b070e02a1.js" crossorigin="anonymous"></script>
    <title>Index</title>
</head>
<body>

    <!-- navbar logo :: starts -->
    <nav>
        <div class="header">
        <div class="header-logo">
            <div class=" logo1 col-sm-2 text-center">
                <img src="./images/TNPSC-logo1.jpg" alt="">
            </div>
            <div class=" logo2 col-md-8 text-center">
                <img src="./images/TNPSC-logo2.png" alt="">
            </div>
            <div class=" logo3 col-md-2 text-center">
                <img src="./images/90year.jpg" alt="">
            </div>
        </div>
        </div>
    </nav>
    <!-- navbar logo :: ends -->

    <!-- Navbar :: starts -->
<nav class="navbar navbar-expand-sm navbar-dark ">
    <div class="container-fluid">
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#"><b>Home</b></a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">About us</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link active" href="#">Recuritment</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Employee Corner</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Government users</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">RTI & Public Grievance</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">FAQ</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Forms & Downloads</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Links</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Tenders</a>
          </li>

            </ul>
          </li>
          
        </ul>
       
      </div>
    </div>
  </nav>

        
        <div class="form-title">TNPSC Online Registeration Portal</div>
        <div class="reg-forms"><br>
            <form class="reg-form1" action="insert2.php" method="post">
              <fieldset class="fieldset">
                <div class="fieldset-ele">
                <br><h4 class="h4">Communication Details</h4><br>
             <label>Email ID:<sup>*</sup></label>
             <input type="email"  name="email" class="form-input"   size="30" >
              <br><br>
              <label>Mobile No:<sup>*</sup></label>
              <input type="text"  name="mobileno" class="form-input"  size="10" placeholder="9876543210" >
              <br><br>
              <label>Login ID<sup>*</sup></label>
              <input type="text" name="loginid" class="form-input"  ><br><br>
              <label>Password:<sup>*</sup></label>
              <input type="password" id="password" name="password" class="form-input"  ><br><br>
              <label>Address:</label><br>
              <!-- <input type="textarea" class="form-input" id="f-address" rows="10"><br><br> -->
              <textarea name="address" id="address" cols="40" rows="4"></textarea><br><br>
              <input type="checkbox"> <label>Check it</label><br><br>

              <div class="form-button">
                <!-- <button class="button1" ><a href="registeration1.html" style="color:white ;">Back</a></button> -->
                <button class="button2" ><!--<a href="registeration3.html" style="color:white ;">Next</a>-->Submit</button>
                </div>
                  <br><br> 

            </fieldset>
          </div>
            </form>
        </div>

<br><br>



<!-- Footer :: starts -->
<footer>
    <img src="./images/india.gov.in.jpg" alt="">
    <div class="con">
    <div>© Tamil Nadu Public Service Commission, TNPSC Road, Broadway, Chennai-600003. </div>
    <!-- <div>Email: grievance[dot]tnpsc[at]tn[dot]gov[dot]in</div> -->
</div>
    <img class="footer-img2" src="./images/tn.gov.in2.jpg" alt="">
</footer>
<!-- Footer :: ends -->

</body>
</html>