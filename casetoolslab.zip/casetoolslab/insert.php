<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=mysqli_connect($server,$username,$password,$dbname);
if(isset($_POST['sinitial'])&& !empty($_POST['name'])&& !empty($_POST['finitial'])&& !empty($_POST['fname'])&& !empty($_POST['dob'])&& !empty($_POST['gender'])&& !empty($_POST['sslcregno'])&& !empty($_POST['yearofpass'])&& !empty($_POST['board'])){
   $sinitial=$_POST['sinitial'];
   $name=$_POST['name'];
   $finitial=$_POST['finitial'];
   $fname=$_POST['fname'];
   $dob=$_POST['dob'];
   $gender=$_POST['gender'];
   $sslcregno=$_POST['sslcregno'];
   $yearofpass=$_POST['yearofpass'];
   $board=$_POST['board'];
   $query="insert into form(sinitial,name,finitial,fname,dob,gender,sslcregno,yearofpass,board) values('$sinitial','$name','$finitial','$fname','$dob','$gender','$sslcregno','$yearofpass','$board')";
   $run=mysqli_query($conn,$query)or die(mysqli_error());
   if($run){
    echo"form submitted";
   }
   else{
    echo"form not submitted";
   }
}
else{
    echo"all feilds are required";
}
?>