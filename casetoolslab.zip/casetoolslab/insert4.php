<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=mysqli_connect($server,$username,$password,$dbname);
if(isset($_POST['photo'])&& !empty($_POST['sign'])&& !empty($_POST['marksheet'])&& !empty($_POST['community'])&& !empty($_POST['no_community'])&& !empty($_POST['aadhaar'])&& !empty($_POST['physical'])&& !empty($_POST['widow'])){
   $photo=$_POST['photo'];
   $sign=$_POST['sign'];
   $marksheet=$_POST['marksheet'];
   $community=$_POST['community'];
   $no_community=$_POST['no_community'];

   $aadhaar=$_POST['aadhaar'];
   $physical=$_POST['physical'];
   $widow=$_POST['widow'];
   
   $query="insert into form4(photo,sign,marksheet,community,no_community,aadhaar,physical,widow) values('$photo','$sign','$marksheet','$community','$no_community','$aadhaar','$physical','$widow')";
   $run=mysqli_query($conn,$query)or die(mysqli_error());
   if($run){
    echo"form submitted";
   }
   else{
    echo"form not submitted";
   }
}
else{
    echo"all feilds are required";
}
?>