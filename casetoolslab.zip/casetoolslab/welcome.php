<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="./styles/index.css">
        
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>

<nav>
            <div class="header">
            <div class="header-logo">
                <div class=" logo1 col-sm-2 text-center">
                    <img src="./images/TNPSC-logo1.jpg" alt="">
                </div>
                <div class=" logo2 col-md-8 text-center">
                    <img src="./images/TNPSC-logo2.png" alt="">
                </div>
                <div class=" logo3 col-md-2 text-center">
                    <img src="./images/90year.jpg" alt="">
                </div>
            </div>
            </div>
        </nav>
    
    <!-- Navbar :: starts -->
    <nav class="navbar navbar-expand-sm navbar-dark py-0 ">
        <div class="container-fluid">
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"><b>Home</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/casetoolslab/login.php">LOGIN</a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link active" href="#">Recuritment</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="#">Employee Corner</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="./search.html">Display</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="#">RTI & Public Grievance</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="#">FAQ</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="#">Forms & Downloads</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/casetoolslab/register.php">Register</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/casetoolslab/index1.php">ADMIN LOGIN</a>
              </li>
    
                </ul>
              </li>
              
            </ul>
           
          </div>
        </div>
      </nav>
    <!-- Navbar :: ends -->
    
    
       
        <!-- navbar logo :: ends -->
            <!-- Scroll ::starts -->
            <div class="scroller col-md-8 col-sm-6 col-xs-12">
                <marquee behavior="scroll" direction="left">Welcome to TamilNadu Public Service Commission.</marquee>
            </div>
            <!-- Scroll ::ends -->
    <br><br>
    
    <h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
    <p>
        <a href="reset-password.php" class="btn btn-primary">Reset Your Password</a>
        <a href="logout.php" class="btn btn-success ml-3">Sign Out of Your Account</a>


        <a href="./registeration1.html"   class="btn btn-primary"> Click here to fill form</a>
    </p>
    
    <!-- Login :: Ends -->
    <br><br>
    
    <!-- Footer :: starts -->
    <footer>
        <img src="./images/india.gov.in.jpg" alt="">
        <div class="con">
        <div>© Tamil Nadu Public Service Commission, TNPSC Road, Broadway, Chennai-600003. </div>
        <!-- <div>Email: grievance[dot]tnpsc[at]tn[dot]gov[dot]in</div> -->
    </div>
        <img class="footer-img2" src="./images/tn.gov.in2.jpg" alt="">
    </footer>










    
</body>
</html>