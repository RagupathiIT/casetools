-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2020 at 07:20 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
-- START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--



-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `form` (
  `id` int(11) NOT NULL,
  `sinitial` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `finitial` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `sslcregno` varchar(100) NOT NULL,
  `yearofpass` varchar(100) NOT NULL,
  `board` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `form` (`id`, `sinitial`, `name`, `finitial`, `fname`, `dob`, `gender`, `sslcregno`, `yearofpass`, `board`) VALUES
(13, 'A', 'Raja', 'H', 'Ram', '2.1.2003', 'male', '1013', '2018', 'CBSC'),
(14, 'B', 'Sekar', 'I', 'Raja', '5.2.2001', 'male', '1014', '2016', 'CBSC'),
(15, 'C', 'Sham', 'J', 'Sekar', '6.3.2002', 'male', '1015', '2017', 'CBSC'),
(16, 'D', 'Naveen', 'K', 'Sham', '7.4.2003', 'male', '1016', '2018', 'CBSC'),
(17, 'E', 'Adam', 'L', 'Naveen', '8.5.2000', 'male', '1017', '2015', 'CBSC'),
(18, 'F', 'Anbu', 'M', 'Adam', '9.6.2000', 'male', '1018', '2015', 'CBSC'),
(19, 'G', 'Vetri', 'N', 'Anbu', '10.7.2001', 'male', '1019', '2016', 'CBSC'),
(20, 'H', 'Riya', 'O', 'Ram', '2.1.2003', 'female', '1020', '2018', 'CBSC'),
(21, 'I', 'Reena', 'P', 'Raja', '5.2.2001', 'female', '1021', '2016', 'CBSC'),
(22, 'J', 'Sruthi', 'Q', 'Sekar', '6.3.2002', 'female', '1022', '2017', 'CBSC'),
(23, 'K', 'Anusha', 'R', 'Sham', '7.4.2003', 'female', '1023', '2018', 'CBSC'),
(24, 'L', 'Devi', 'S', 'Naveen', '8.5.2000', 'female', '1024', '2015', 'CBSC'),
(25, 'M', 'Dolly', 'T', 'Adam', '9.6.2000', 'female', '1025', '2015', 'CBSC'),
(26, 'N', 'Sweety', 'U', 'Anbu', '10.7.2001', 'female', '1026', '2016', 'CBSC');

--se candidates--
(52, 'A', 'Priya', 'K', 'Anbu', '11.7.2001', 'female', '1052', '2016', 'CBSC'),
(53, 'B', 'Swetha', 'L', 'Anbu', '12.7.2001', 'female', '1053', '2016', 'CBSC'),
(54, 'C', 'Sunitha', 'M', 'Anbu', '13.7.2001', 'female', '1054', '2016', 'CBSC'),
(55, 'D', 'Anu', 'N', 'Anbu', '14.7.2001', 'female', '1055', '2016', 'CBSC'),
(56, 'E', 'Anish', 'O', 'Anbu', '15.7.2001', 'male', '1056', '2016', 'CBSC'),
(57, 'F', 'Sureh', 'P', 'Anbu', '16.7.2001', 'male', '1057', '2016', 'CBSC'),
(58, 'G', 'Ramesh', 'Q', 'Anbu', '17.7.2001', 'male', '1058', '2016', 'CBSC'),
(59, 'H', 'Rihaan', 'R', 'Anbu', '18.7.2001', 'male', '1059', '2016', 'CBSC'),
(60, 'I', 'Vihaan', 'S', 'Anbu', '19.7.2001', 'male', '1060', '2016', 'CBSC'),
(61, 'J', 'Riyan', 'T', 'Anbu', '20.7.2001', 'male', '1061', '2016', 'CBSC');




-- (3, 'p', 'p', 'p', 'p', '1', 'nidsyeyg', '400', 'Not Void', ''),
-- (4, 'k', 'k', 'k', 'k', '1', 'v53zohwk', '400', '', ''),
-- (5, 'k', 'k', 'k', 'k', '1', 's4xf7qkq', '400', '', '1, 2, 3, 4, 5, 6, 7, 8, 9, '),
-- (6, 'k', 'k', 'k', 'k', '1', 'fhk7qarc', '1600', '', '1, 2, 3, 4, '),
-- (7, 'John', 'Smith', '2345678', 'Saple Address', '1', 'h68u6ksu', '1200', 'Onboard', '1, 2, 3, '),
-- (8, 'John', 'Smith', '2345678', 'Saple Address', '5', 'vsuucxgy', '174', '', '1, 2, 3, ');

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE `form2` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `loginid` varchar(100) NOT NULL,
  `sslcregno` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve`
--

INSERT INTO `form2` (`id`, `email`, `mobileno`, `loginid`, `sslcregno`, `address`) VALUES
(13, 'raja@gmail.com', '9976543210', 'raja', '1013', 'Kondur Cuddalore'),
(14, 'sekar@gmail.com', '9886543210', 'sekar', '1014', 'Sidambaram Cuddalore'),
(15, 'sham@gmail.com', '9877543210', 'sham', '1015', 'Nellikuppam Tiruppur'),
(16, 'naveen@gmail.com', '9876643210', 'naveen', '1016', 'Dharapuram Cuddalore'),
(17, 'adam@gmail.com', '9876553210', 'adam', '1017', 'Kottar Nagercoil'),
(18, 'anbu@gmail.com', '9876544210', 'anbu', '1018', 'Kottar Nagapatnam'),
(19, 'vetri@gmail.com', '9876543310', 'vetri', '1019', 'Sidambaram Cuddaore'),
(20, 'riya@gmail.com', '9976543211', 'raja', '1020', 'Kondur Cuddalore'),
(21, 'reena@gmail.com', '9886543212', 'sekar', '1021', 'Sidambaram Cuddalore'),
(22, 'sruthi@gmail.com', '9877543213', 'sham', '1022', 'Nellikuppam Tiruppur'),
(23, 'anusha@gmail.com', '9876643214', 'naveen', '1023', 'Dharapuram Cuddalore'),
(24, 'devi@gmail.com', '9876553215', 'adam', '1024', 'Kottar Nagercoil'),
(25, 'dolly@gmail.com', '9876544216', 'anbu', '1025', 'Kottar Nagapatnam'),
(26, 'sweety@gmail.com', '9876543317', 'vetri', '1026', 'Sidambaram Cuddalore');


-----see------

(52, 'priya@gmail.com', '9176543210', 'priya', '1052', 'Kondur Cuddalore'),
(53, 'swetha@gmail.com', '9286543210', 'swetha', '1053', 'Sidambaram Cuddalore'),
(54, 'sunitha@gmail.com', '9377543210', 'sunitha', '1054', 'Nellikuppam Tiruppur'),
(55, 'anu@gmail.com', '9476643210', 'anu', '1055', 'Dharapuram Cuddalore'),
(56, 'anish@gmail.com', '9576553210', 'anish', '1056', 'Kottar Nagercoil'),
(57, 'suresh@gmail.com', '9676544210', 'suresh', '1057', 'Kottar Nagapatnam'),
(58, 'ramesh@gmail.com', '9776543310', 'ramesh', '1058', 'Sidambaram Cuddaore'),
(59, 'rihaan@gmail.com', '9876543211', 'rihaan', '1059', 'Kondur Cuddalore'),
(60, 'viyaan@gmail.com', '9986543212', 'viyaan', '1060', 'Sidambaram Cuddalore'),
(61, 'riyan@gmail.com', '9077543213', 'riyan', '1061', 'Nellikuppam Tiruppur');

-- (2, '2013-01-13', '1', '1', 'kd77mzfy', '1'),
-- (3, '2013-01-15', '1', '5', 'nidsyeyg', '1'),
-- (4, '2013-01-17', '1', '4', 'v53zohwk', '1'),
-- (5, '2013-01-16', '1', '9', 's4xf7qkq', '1, 2, 3, 4, 5, 6, 7, 8, 9, '),
-- (6, '2013-01-21', '1', '4', 'fhk7qarc', '1, 2, 3, 4, '),
-- (7, '10/12/2020', '1', '3', 'h68u6ksu', '1, 2, 3, '),
-- (8, '18/12/2020', '5', '3', 'vsuucxgy', '1, 2, 3, ');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `form3` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `currentstatus` varchar(30) NOT NULL,
  `nationality` varchar(30) NOT NULL,
  `religion` varchar(300) NOT NULL,
  `community` varchar(300) NOT NULL,
  `caste` varchar(300) NOT NULL,
  `birthplace` varchar(300) NOT NULL,
  `native` varchar(300) NOT NULL,
  `candidatemobile` varchar(300) NOT NULL,
  `maritalstatus` varchar(300) NOT NULL,
  `gender` varchar(300) NOT NULL,
  `widow` varchar(300) NOT NULL,
  `fathersname` varchar(30) NOT NULL,
  `mothersname` varchar(30) NOT NULL,
  `sslcregno` varchar(300) NOT NULL,
  `sslcmark` varchar(300) NOT NULL,
  `sslcpercentage` varchar(30) NOT NULL,
  `hscmark` varchar(300) NOT NULL,
  `hscpercentage` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `route`
--

INSERT INTO `form3` (`id`, `name`, `currentstatus`, `nationality`, `religion`, `community`, `caste`, `birthplace`, `native`, `candidatemobile`, `maritalstatus`, `gender`, `widow`, `fathersname`, `mothersname`, `sslcregno`, `sslcmark`, `sslcpercentage`, `hscmark`, `hscpercentage`) VALUES
(13, 'Raja', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Kondur', 'Cuddalore', '9976543210', 'no', 'male', 'no', 'Ram', 'Priya', '1013', '401', '80.2', '480', '80'),
(14, 'Sekar', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Sidamabaram', 'Cuddalore', '9886543210', 'no', 'male', 'no', 'Raja', 'Priya', '1014', '446', '82.2', '490', '81.6'),
(15, 'Sham', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Nellikuppam', 'Tiruppur', '9876543210', 'no', 'male', 'no', 'Sekar', 'Priya', '1015', '450', '90', '500', '83.33'),
(16, 'Naveen', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Dharapuram', 'Cuddalore', '9876643210', 'no', 'male', 'no', 'Sham', 'Priya', '1016', '440', '88', '444', '74'),
(17, 'Adam', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Kottar', 'Nagerkoil', '9876553210', 'no', 'male', 'no', 'Naveen', 'Priya', '1017', '450', '90', '476', '79.33'),
(18, 'Anbu', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Kottar', 'Nagapatnam', '9876544210', 'no', 'male', 'no', 'Adam', 'Priya', '1018', '400', '80', '480', '80'),
(19, 'Vetri', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Sidamabaram', 'Cuddalore', '9876543310', 'no', 'female', 'no', 'Anbu', 'Priya', '1019', '300', '60', '330', '55'),
(20, 'Riya', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Kondur', 'Cuddalore', '9976543211', 'no', 'female', 'no', 'Ram', 'Priya', '1020', '401', '80.2', '480', '80'),
(21, 'Reena', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Sidamabaram', 'Cuddalore', '9886543212', 'no', 'female', 'no', 'Raja', 'Priya', '1021', '446', '82.2', '490', '81.6'),
(22, 'Sruthi', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Nellikuppam', 'Tiruppur', '9876543213', 'no', 'female', 'no', 'Sekar', 'Priya', '1022', '450', '90', '500', '83.33'),
(23, 'Anusha', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Dharapuram', 'Cuddalore', '9876643214', 'no', 'female', 'no', 'Sham', 'Priya', '1023', '440', '88', '444', '74'),
(24, 'Devi', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Kottar', 'Nagerkoil', '9876553215', 'yes', 'female', 'yes', 'Naveen', 'Priya', '1024', '450', '90', '476', '79.33'),
(25, 'Dolly', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Kottar', 'Nagapatnam', '9876544216', 'yes', 'female', 'yes', 'Adam', 'Priya', '1025', '400', '80', '480', '80'),
(26, 'Sweety', 'student', 'Indian', 'Hindu', 'BC', 'abc', 'Sidamabaram', 'Cuddalore', '9876543317', 'yes', 'female', 'yes', 'Anbu', 'Priya', '1026', '300', '60', '330', '55');





--se------
(52, 'Priya', 'student', 'Indian', 'Hindu', 'Sc', 'abc', 'Kondur', 'Cuddalore', '9176543210', 'yes', 'female', 'yes', 'Ram', 'Priya', '1013', '401', '80.2', '480', '80'),
(53, 'Swetha', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Sidamabaram', 'Cuddalore', '9286543210', 'yes', 'female', 'yes', 'Raja', 'Priya', '1014', '446', '82.2', '490', '81.6'),
(54, 'Sunitha', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Nellikuppam', 'Tiruppur', '9376543210', 'no', 'female', 'no', 'Sekar', 'Priya', '1015', '450', '90', '500', '83.33'),
(55, 'Anu', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Dharapuram', 'Cuddalore', '9476643210', 'no', 'female', 'no', 'Sham', 'Priya', '1016', '440', '88', '444', '74'),
(56, 'Anish', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Kottar', 'Nagerkoil', '9576553210', 'no', 'male', 'no', 'Naveen', 'Priya', '1017', '450', '90', '476', '79.33'),
(57, 'Suresh', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Kottar', 'Nagapatnam', '9676544210', 'no', 'male', 'no', 'Adam', 'Priya', '1018', '400', '80', '480', '80'),
(58, 'Ramesh', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Sidamabaram', 'Cuddalore', '9776543310', 'no', 'female', 'no', 'Anbu', 'Priya', '1019', '300', '60', '330', '55'),
(59, 'Rihaan', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Kondur', 'Cuddalore', '9876543211', 'no', 'female', 'no', 'Ram', 'Priya', '1020', '401', '80.2', '480', '80'),
(60, 'Viyaan', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Sidamabaram', 'Cuddalore', '9986543212', 'no', 'female', 'no', 'Raja', 'Priya', '1021', '446', '82.2', '490', '81.6'),
(61, 'riyan', 'student', 'Indian', 'Hindu', 'SC', 'abc', 'Nellikuppam', 'Tiruppur', '9076543213', 'no', 'female', 'no', 'Sekar', 'Priya', '1022', '450', '90', '500', '83.33');






ALTER TABLE `form`
  ADD PRIMARY KEY (`sslcregno`);

--
-- Indexes for table `reserve`
--
ALTER TABLE `form2`
  ADD PRIMARY KEY (`sslcregno`);

--
-- Indexes for table `route`
--
ALTER TABLE `form3`
  ADD PRIMARY KEY (`sslcregno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
-- ALTER TABLE `form`
--   MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

-- --
-- -- AUTO_INCREMENT for table `customer`
-- --
-- ALTER TABLE `form2`
--   MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

-- --
-- -- AUTO_INCREMENT for table `reserve`
-- --
-- ALTER TABLE `form3`
--   MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

-- --
-- AUTO_INCREMENT for table `route`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
