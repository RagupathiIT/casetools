<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=mysqli_connect($server,$username,$password,$dbname);
if(isset($_POST['email'])&& !empty($_POST['mobileno'])&& !empty($_POST['loginid'])&& !empty($_POST['password'])&& !empty($_POST['address'])){
   $email=$_POST['email'];
   $mobileno=$_POST['mobileno'];
   $loginid=$_POST['loginid'];
   $password=$_POST['password'];
   $address=$_POST['address'];
   
   $query="insert into form2(email,mobileno,loginid,password,address) values('$email','$mobileno','$loginid','$password','$address')";
   $run=mysqli_query($conn,$query)or die(mysqli_error());
   if($run){
    echo"form submitted";
   }
   else{
    echo"form not submitted";
   }
}
else{
    echo"all feilds are required";
}
?>