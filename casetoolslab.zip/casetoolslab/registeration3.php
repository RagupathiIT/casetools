<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/registeration3.css">
    <script src="https://kit.fontawesome.com/2b070e02a1.js" crossorigin="anonymous"></script>
    <title>Index</title>
</head>
<body>

    <!-- navbar logo :: starts -->
    <nav>
        <div class="header">
        <div class="header-logo">
            <div class=" logo1 col-sm-2 text-center">
                <img src="./images/TNPSC-logo1.jpg" alt="">
            </div>
            <div class=" logo2 col-md-8 text-center">
                <img src="./images/TNPSC-logo2.png" alt="">
            </div>
            <div class=" logo3 col-md-2 text-center">
                <img src="./images/90year.jpg" alt="">
            </div>
        </div>
        </div>
    </nav>
    <!-- navbar logo :: ends -->

    <!-- Navbar :: starts -->
<nav class="navbar navbar-expand-sm navbar-dark ">
    <div class="container-fluid">
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#"><b>Home</b></a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">About us</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link active" href="#">Recuritment</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Employee Corner</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Government users</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">RTI & Public Grievance</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">FAQ</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Forms & Downloads</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Links</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">Tenders</a>
          </li>

            </ul>
          </li>
          
        </ul>
       
      </div>
    </div>
  </nav>

        
        <div class="form-title">TNPSC Online Registeration Portal</div>
        <div class="reg-forms"><br>
            <form class="reg-form1" action="insert3.php" method="post">
              <fieldset class="fieldset">
                <div class="fieldset-ele">
                <br><h4 class="h4">General Details</h4><br>

             <label>Name:<sup>*</sup></label>
             <input type="text"  id="name" name="name" class="form-input" >
              <br><br>

              <label>Current status of candidate:</label>
              <select name="currentstatus" class="form-input" id="status" >
                <option value="select" >--Select--</option>
                <option value="student" name="student">Student</option>
                <option value="employee" name="employee">Employee</option>
                <option value="others" name="others">Others</option> 
              </select><br><br>

              <label>Nationality:</label>
              <input type="radio" for="indian" name="nationality" class="form-input" id="indian" >Indian
              <input type="radio" for="others" name="nationality" class="form-input" id="others" >Others<br><br>

              <label>Religion:</label>
              <select name="religion" class="form-input" id="religion" >
                <option value="select" >--Select--</option>
                <option value="hindu" name="hindu">Hindu</option>
                <option value="christian" name="christian">Christian</option>
                <option value="muslim" name="muslim">Muslim</option> 
              </select><br><br>

              <label>Communal Category:</label>
              <select name="community" class="form-input" id="community" >
                <option value="select" >--Select--</option>
                <option value="OC" name="OC">General (OC)</option>
                <option value="BC" name="BC">BC</option>
                <option value="MBC" name="MBC">MBC</option>
                <option value="SC" name="SC">SC</option>
                <option value="ST" name="ST">ST</option>
                <option value="no community" name="no community">No Community</option>
              </select><br><br>

              <label>Name of the Sub Caste:</label>
              <input type="text"  id="caste" name="caste" class="form-input" >
               <br><br>

               <label>Candidate place of Birth:</label>
               <input type="text"  id="place-birth" name="birthplace" class="form-input" >
                <br><br>

                <label>Native District:</label>
               <input type="text"  id="native" name="native" class="form-input" >
                <br><br>

              <label>Candidate Mobile No:<sup>*</sup></label>
              <input type="text"  id="c-mobile" name="candidatemobile" class="form-input"  size="10" placeholder="9876543210" >
              <br><br>

              <label>Marital Status:</label>
              <input type="radio" for="yes" name="maritalstatus" class="form-input" id="yes" >Yes
              <input type="radio" for="no" name="maritalstatus" class="form-input" id="no" >No<br><br>

              <label>Gender:</label>
              <input type="radio" for="male" name="gender" class="form-input" id="f-male" >Male
              <input type="radio" for="female" name="gender" class="form-input" id="f-female" >Female<br><br>

              <label>Widow:</label>
              <input type="radio" for="yes" name="widow" class="form-input" id="yes" >Yes
              <input type="radio" for="no" name="widow" class="form-input" id="no" >No<br><br>

              <label>Father's Name:</label>
             <input type="text"  id="father-name" name="fathersname" class="form-input" >
              <br><br>

              <label>Mother's Name:</label>
             <input type="text"  id="mother-name" name="mothersname" class="form-input" >
              <br><br>

              <label>Parent Mobile No:<sup>*</sup></label>
              <input type="text"  id="p-mobile" name="parentmobile" class="form-input"  size="10" placeholder="9876543210" >
              <br><br>

              <!-- <div class="form-button">
                <button class="button1" ><a href="registeration2.html" style="color:white ;">Back</a></button>
                <button class="button2" ><a href="https://www.google.co.in/" style="color:white ;">Next</a></button>
                </div> -->
                  <br><br> 

                  

            </fieldset>

<br>
            <!-- Qualification :: starts -->
            <fieldset class="fieldset">
              <div class="fieldset-ele">
              <br><h4 class="h4">Qualification Details</h4><br>
           
              <label>SSLC Mark:</label>
              <input type="text"  id="sslc-mark" name="sslcmark" class="form-input" >
               <br><br>

               <label>SSLC Percentage:</label>
             <input type="text"  id="sslc-percentage" name="sslcpercentage" class="form-input" >
              <br><br>

              <label>HSC Mark:</label>
              <input type="text"  id="hsc-mark" name="hscmark" class="form-input" >
               <br><br>

               <label>HSC Percentage:</label>
             <input type="text"  id="hsc-percentage" name="hscpercentage" class="form-input" >
              <br><br>

            <!-- <div class="form-button">
              <button class="button1" ><a href="index.html" style="color:white ;">Back</a></button>
              <button class="button2" ><a href="registeration2.html" style="color:white ;">Next</a></button>
              </div> -->
                <br><br> 

          </fieldset>
          <!-- Qualification  :: ends -->
          <br>
          <div class="form-button">
            <!-- <button class="button1" ><a href="registeration2.html" style="color:white ;">Back</a></button> -->
            <button class="button2" ><!--<a href="registeration4.html" style="color:white ;">Next</a>-->submit</button>
            </div>
          </div>
          
            </form>

            
        </div>


        
<br><br>








<!-- Footer :: starts -->
<footer>
    <img src="./images/india.gov.in.jpg" alt="">
    <div class="con">
    <div>© Tamil Nadu Public Service Commission, TNPSC Road, Broadway, Chennai-600003. </div>
    <!-- <div>Email: grievance[dot]tnpsc[at]tn[dot]gov[dot]in</div> -->
</div>
    <img class="footer-img2" src="./images/tn.gov.in2.jpg" alt="">
</footer>
<!-- Footer :: ends -->

</body>
</html>